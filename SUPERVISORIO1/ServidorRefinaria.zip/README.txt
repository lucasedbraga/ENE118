Para rodar o servidor, basta executar o arquivo: ServidorRefinaria.exe que está dentro da pasta ServidorMODBUS
Verifique as regras do seu antivírus para que ele não bloqueie a execução do software.